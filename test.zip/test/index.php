<!DOCTYPE html>
<html lang="ru">
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name=keywords content="Атон электрооборудование прожектор светильник кабель щитовое оборудование" />
      <meta name=description content="ООО «АТОН» осуществляет комплексные поставки оборудования для производственных предприятий: прожектора, светильники с различной степенью защиты, кабельная продукция различного профиля и сечения, изделия для прокладки кабеля, щитовое оборудование, низковольтное оборудование." />
      <link rel="icon" href="/img/favicon.ico" type="image/x-icon">
      <title>ООО &laquo;Атон&raquo;</title>
      <link rel="stylesheet" href="/bootstrap4/css/bootstrap.min.css" >
      <link rel="stylesheet" href="/fonts/fontawesome5/css/all.css">
      <link rel="stylesheet" href="style.css">
      <link rel="stylesheet" href="/js/slick/slick.css"/>
      <link rel="stylesheet" href="/js/slick/slick-theme.css"/>
      <script defer src="/fonts/fontawesome5/js/all.js"></script>
      <script defer src="/bootstrap4/js/bootstrap.min.js"></script>
   </head>
   <body>
      <div class="container_wrp">
         <header id="header">
            <nav class="container">
               <input type="checkbox" id="checkbox" class="mobile-menu__checkbox">
               <label for="checkbox" class="mobile-menu__btn">
               <span class="mobile-menu__icon"></span>
               </label>
               <div class="logo__mob">
                  <picture class="logo-menu__mob">
                     <source srcset="./img/logo-blue.webp" type="image/webp">
                     <img src="./img/logo-blue.png" height="83" alt="logo">
                  </picture>
                  <div class="logo-h2_span__mob">
                     <h2 class="logo_h2">Компания АТОН</h2>
                     <span class="logo_span">Продажа электрооборудования</span>
                  </div>
               </div>
               <div class="mobile-menu__container" id="mobile-menu__container">
                  <ul class="nav">
                     <li class="menu__item"><a class="menu__item-a" href="#product">Продукция</a></li>
                     <li class="menu__item"><a class="menu__item-a" href="#services">Услуги</a></li>
                     <li class="menu__item-logo">
                        <img class="arrow-heder-logo" src="./img/main-arrow-heder1.png" alt="main-arrow-heder"> 
                        <div class="logo_hed__block">
                           <picture class="logo_img2" id="logo">
                              <source srcset="./img/logo.webp" type="image/webp">
                              <img  class="logo_img2" src="./img/logo.png" height="101" alt="logo">
                           </picture>
                           <h2 class="logo_h2">Компания АТОН</h2>
                           <span class="logo_span">Продажа электрооборудования</span>
                        </div>
                        <p class="logo_p">Мы&nbsp;рады приветствовать Вас на&nbsp;нашем сайте. У&nbsp;нас&nbsp;Вы можете найти любое интересующее Вас электротехническое оборудование по&nbsp;оптовым ценам</p>
                     </li>
                     <li class="menu__item"><a class="menu__item-a" href="#company">О&nbsp;компании</a></li>
                     <li class="menu__item"><a class="menu__item-a" href="#contacts">Контакты</a></li>
                  </ul>
               </div>
            </nav>
         </header>
         <section class="main_hed">
            <div class="main_hed-img"></div>
            <img  class="arrow-hed-form-tablet1" src="./img/arrow-hed-form-tablet.svg" height="291" alt="arrow">
            <img  class="arrow-hed-form-tablet2" src="./img/arrow-hed-form-tablet.svg" height="291" alt="arrow">
            <img  class="arrow-hed-form-tablet3" src="./img/arrow-hed-form-tablet2.svg" height="291" alt="arrow">
            <div class="form_heder-wrp">
               <form id="form_heder" action="#" method="post" name="request_action">
                  <!-- Hidden Required Fields -->
                  <input type="hidden" name="project_name" value="info@tk-aton.ru">
                  <input type="hidden" name="admin_email" value="info@tk-aton.ru">
                  <input type="hidden" name="form_subject" value="Запрос звонка с сайта tk-aton.ru">
                  <h3 class="form_heder_title">Вы&nbsp;&mdash; индивидуальны<br>Мы&nbsp;&mdash; компетентны</h3>
                  <span class="form_heder_span">Свяжитесь с&nbsp;нами мы&nbsp;предложим лучшее решение под Ваши потребности и
                  цели</span>
                  <input class="form_heder-input" id="username" type="text" required="required" minlength="3"
                     maxlength="50" placeholder="Имя" name="Имя">
                  <input class="form_heder-input" id="mail" type="text" required="required" minlength="6" maxlength="28"
                     placeholder="Email" name="Email">
                  <input class="form_heder-input" id="phone" type="tel" required="required" minlength="6" maxlength="20"
                     placeholder="Телефон" name="Телефон">
                  <div class="fi">
                     <label class="privatePolocy_wrp">
                     <input class="checkbox" id="privatePolocy1" aria-hidden="true" type='checkbox'
                        onchange="document.getElementById('submit').disabled = !this.checked" checked required value="Пользователь принял условия использования данных"/>
                     <span><span class="privat-policy">Я&nbsp;принимаю условия использования
                     данных</span></span> 
                     </label> <i class="fas fa-info-circle" data-toggle="modal" data-target="#privatPolicyall"></i>
                  </div>
                  <input type="hidden" id="recaptchaV3">
                  <div class="fi">
                     <label>
                     <button id="submit" type="submit" class="form_heder-btn">Заказать звонок</button>
                     </label>
                  </div>
                  <div id="good_massege_call"></div>
               </form>
            </div>
         </section>
         <section class="main_hed2">
            <div class="main_hed2-block1">
               <div class="mh2_img_wrp">
                  <picture class="mh2_img">
                     <source srcset="./img/logo-blue.webp" type="image/webp">
                     <img src="./img/logo-blue.png" height="83" alt="logo">
                  </picture>
                  <h2 class="mh2_img_h2">Компания АТОН</h2>
                  <span class="mh2_img_span">Продажа электрооборудования</span>
               </div>
               <p>Мы&nbsp;рады приветствовать Вас на&nbsp;нашем сайте. Здесь Вы&nbsp;можете найти любое интересующее Вас электротехническое оборудование по&nbsp;оптовым ценам</p>
               <img class="main_hed2-arrow2" src="./img/arrow-blue-2.svg" height="103" width="168" alt="arrow-blue">
            </div>
            <div class="main_hed2-block2"></div>
            <div class="logo_white2">
               <picture class="logo_img2" id="logo2">
                  <source srcset="./img/logo.webp" type="image/webp">
                  <img  class="logo_img2" src="./img/logo.png" height="101" alt="logo">
               </picture>
               <h2 class="logo_h2">Компания АТОН</h2>
               <span class="logo_span">Продажа электрооборудования</span>
               <img class="arrow-heder-logo_mob" src="./img/main-arrow-heder1.png" alt="arrow-heder-logo_mob"> 
            </div>
            <img class="arrow-heder-logo_mob2" src="./img/main-arrow-heder1-mob.png" alt="arrow-heder-logo_mob"> 
            <div class="main_hed2-block3">
               <img class="main_hed2-arrow1" src="./img/arrow-blue-1.svg" height="200" width="91" alt="arrow-blue">
               <h3>Наши услуги</h3>
               <p>ООО &laquo;АТОН&raquo; осуществляет комплексные поставки оборудования для производственных предприятий: прожектора, светильники с&nbsp;различной степенью защиты, кабельная продукция различного профиля и&nbsp;сечения, изделия для прокладки кабеля, щитовое оборудование, низковольтное оборудование.</p>
               <p>Также у&nbsp;нас&nbsp;Вы можете приобрести электротехнические изделия для дома: люстры, светильники, светодиодные ленты, розетки, выключатели, рамки, диммеры, совмещенные блоки, датчики, термостаты, установочные изделия для системы &laquo;Умный дом&raquo;, удлинители и&nbsp;многое другое.</p>
            </div>
         </section>
         <section class="slider_block">
            <h3 class="slider_block-h3" id="product">У&nbsp;нас вы&nbsp;приобретете</h3>
            <img class="arrow-white-slider" src="./img/arrow-white-slider.svg" height="260" width="150" alt="arrow-white-slider" aria-hidden="true">
            <img class="arrow-blue-slider" src="./img/arrow-blue-2.svg" height="111" width="68" alt="arrow-blue" aria-hidden="true"> 
            <div class="slider">
               <div class="slider-item clip">
                  <img class="slider_img" src="./img/cable.png" height="236" width="317" alt="cable">
                  <div class="slider-item-text">
                     <h3 class="slider-item_h3">Кабельно-проводниковая продукция</h3>
                     <p class="slider-item_p">Широкий выбор производителей и&nbsp;опыт наших сотрудников,позволит Вам подобрать продукцию наиболее подходящую для Ваших целей</p>
                  </div>
               </div>
               <div class="slider-item clip">
                  <img class="slider_img" src="./img/svet-teh.png" height="236" width="317" alt="svet-teh">
                  <div class="slider-item-text">
                     <h3 class="slider-item_h3">Светотехнические изделия</h3>
                     <p class="slider-item_p">Мы&nbsp;рады предложить Вам широкий ассортимент светотехники. В&nbsp;список продукции входят офисные светильники, прожектора, светильники для уличного освещения и&nbsp;многое другое</p>
                  </div>
               </div>
               <div class="slider-item clip">
                  <img class="slider_img" src="./img/el-ustan-izdelia.png" height="236" width="317" alt="el-ustan-izdelia">
                  <div class="slider-item-text">
                     <h3 class="slider-item_h3">Электроустановочные изделия</h3>
                     <p class="slider-item_p">Широкий выбор производителей и&nbsp;опыт наших сотрудников,позволит Вам подобрать продукцию наиболее подходящую для Ваших целей</p>
                  </div>
               </div>
               <div class="slider-item clip">
                  <img class="slider_img" src="./img/el-montazh-izdelia.png" height="236" width="317" alt="el-montazh-izdelia">
                  <div class="slider-item-text">
                     <h3 class="slider-item_h3">Электромонтажные изделия</h3>
                     <p class="slider-item_p">Электромонтажные изделия это все&nbsp;то, без чего невозможно проведение электромонтажных работ. Сюда входят скобы, клемы, распределительные коробки и&nbsp;многое другое</p>
                  </div>
               </div>
               <div class="slider-item clip">
                  <img class="slider_img" src="./img/oborudov610kv.png" height="236" width="317" alt="oborudov610kv">
                  <div class="slider-item-text">
                     <h3 class="slider-item_h3">Оборудование 6-10кВ</h3>
                     <p class="slider-item_p">Компания &laquo;АТОН&raquo; осуществляет поставку оборудования 6-10кВ. Для более подробной информации обращайтесь<br> к&nbsp;менеджерам ООО &laquo;АТОН&raquo;</p>
                  </div>
               </div>
               <div class="slider-item clip">
                  <img class="slider_img" src="./img/prokladka-kabelia.png" height="236" width="317" alt="prokladka-kabelia">
                  <div class="slider-item-text">
                     <h3 class="slider-item_h3">Изделия для прокладки кабеля</h3>
                     <p class="slider-item_p">Ни&nbsp;одно современное здание нельзя представить без кабельной канализации. В&nbsp;нее укладываются различные кабели для электрических, телефонных, компьютерных, телевизионных сетей</p>
                  </div>
               </div>
            </div>
            <a href="#order" id="submit-slider"  type="button" class="submit-slider-btn">Оставить заявку</a>
         </section>
         <section class="benefits_block">
            <h3 id="services" class="benefits_h3">Преимущества работы с&nbsp;нами</h3>
            <div class="benefits_wrp">
               <div class="benefits_item">
                  <img class="benefits_img" src="./img/benefits1.svg" height="70" width="70" alt="benefits1">
                  <h4 class="benefits_h4">Высокая квалификация</h4>
                  <p class="benefits_p">Наши сотрудники ежегодно проходят обучение, повышают свою квалификацию и&nbsp;всегда готовы реализовать проекты любой сложности</p>
               </div>
               <div class="benefits_item">
                  <img class="benefits_img" src="./img/benefits2.svg" height="70" width="70" alt="benefits2">
                  <h4 class="benefits_h4">Оперативность</h4>
                  <p class="benefits_p">Мы&nbsp;ценим Ваше время! Наша система оперативной связи позволяет нам всегда максимально быстро реагировать на&nbsp;Ваш заказ</p>
               </div>
               <div class="benefits_item">
                  <img class="benefits_img" src="./img/benefits3.svg" height="70" width="70" alt="benefits3">
                  <h4 class="benefits_h4">Индивидуальный подход</h4>
                  <p class="benefits_p">Наша задача удовлетворить потребность в&nbsp;электрооборудовании как крупных, промышленных так и&nbsp;частных заказчиков</p>
               </div>
               <div class="benefits_item">
                  <img class="benefits_img" src="./img/benefits4.svg" height="70" width="70" alt="benefits4">
                  <h4 class="benefits_h4">Гибкая ценовая политика</h4>
                  <p class="benefits_p">Наша ценовая политика рассчитана на&nbsp;любой бюджет и&nbsp;мы&nbsp;всегда стремимся максимально качественно реализовать Ваши задачи</p>
               </div>
               <div class="benefits_item">
                  <img class="benefits_img" src="./img/benefits5.svg" height="70" width="70" alt="benefits5">
                  <h4 class="benefits_h4">Широкий ассортимент</h4>
                  <p class="benefits_p">В&nbsp;нашем каталоге более 150&nbsp;000 наименований продукции производства российских и&nbsp;зарубежных компаний</p>
               </div>
               <div class="benefits_item">
                  <img class="benefits_img" src="./img/benefits6.svg" height="70" width="70" alt="benefits6">
                  <h4 class="benefits_h4">Сертификаты качества</h4>
                  <p class="benefits_p">Мы&nbsp;очень ценим нашу репутацию и&nbsp;поэтому вся реализуемая нами продукция имеет сертификаты качества</p>
               </div>
            </div>
         </section>
         <section class="about_company">
            <h3  id="company" class="about_company__h3">О&nbsp;компании</h3>
            <article class="about_company__wrp">
               <div class="about_company__txt">
                  <h6 class="about_company__p1">Компания АТОН является одним из&nbsp;ведущих поставщиков электротехнической продукции как российских, так и&nbsp;зарубежных производителей. Наша компания успешно работает на&nbsp;рынке электротехнической продукции более 10&nbsp;лет. Благодаря многолетнему опыту и&nbsp;высокой квалификации сотрудников ООО &laquo;АТОН&raquo;, наши партнеры получают оптимальные решения при комплектации своих объектов.</h6>
                  <p class="about_company__p2">ООО &laquo;АТОН&raquo; предлагает широкий ассортимент электротехнической продукции.</p>
                  <ul class="about_company__ul">
                     <li class="about_company__li">кабельно-проводниковая продукция</li>
                     <li class="about_company__li">силовое оборудование (рубильники, контакторы и&nbsp;т.д.)</li>
                     <li class="about_company__li">светотехническое оборудование</li>
                     <li class="about_company__li">светодиодная продукция </li>
                     <li class="about_company__li">установочное оборудование (розетки, выключатели)</li>
                     <li class="about_company__li">щитовое оборудование</li>
                     <li class="about_company__li">инструмент для электромонтажа</li>
                  </ul>
                  <p class="about_company__p3">На&nbsp;сегодняшний день клиентами нашей компании являются производственные предприятия, строительные компании, монтажные организации, проектные организации, дизайнерские студии, индивидуальные предприниматели.</p>
               </div>
               <div class="about_company__img-wrp">
                  <!--<img class="about_company__img" src="./img/about-company.png" height="492" width="670" alt="benefits5">-->
               </div>
            </article>
         </section>
         <section class="order_form" id="order" >
            <h2 class="order_form__h2">Напишите нам</h2>
            <div class="form_footer-wrp">
               <img class="arrow-form_footer1" src="./img/arrow-form_footer.svg" height="207" width="118" alt="arrow">
               <img class="arrow-form_footer2" src="./img/arrow-form_footer.svg" height="207" width="118" alt="arrow">
               <p class="order_form__p">Оставьте нам свои контакты и&nbsp;один из&nbsp;наших менеджеров обязательно свяжется с&nbsp;Вами и&nbsp;даст развернутую консультация касательно Вашего проекта</p>
               <form id="form_footer" action="#" method="post" name="request_action">
                  <!-- Hidden Required Fields -->
                  <input type="hidden" name="project_name" value="info@tk-aton.ru">
                  <input type="hidden" name="admin_email" value="info@tk-aton.ru">
                  <input type="hidden" name="form_subject" value="Заявка с сайта tk-aton.ru">
                  <div class="form_items1">
                     <input class="form_footer-input" id="username_footer" type="text" required="required" minlength="3"
                        maxlength="50" placeholder="Имя" name="Имя">
                     <input class="form_footer-input" id="mail_footer" type="text" required="required" minlength="6" maxlength="28"
                        placeholder="Email" name="Email">
                     <input class="form_footer-input" id="phone_footer" type="tel" required="required" minlength="6" maxlength="20"
                        placeholder="Телефон" name="Телефон">
                  </div>
                  <div class="form_items2"> 
                     <label class="textarea_footer_label" for="textarea_footer">Сообщение</label>
                     <textarea id="textarea_footer" name="story" rows="5" cols="33"></textarea> 
                  </div>
                  <div class="form_items3">
                     <div class="radio_wrp">
                        <div class="form_radio">
                           <input class="custom-radio" id="question1" name="Заказчик" type="radio" value="Частное лицо" checked />
                           <label class="label_check-radio" for="question1">Частное лицо</label>
                        </div>
                        <div class="form_radio">
                           <input class="custom-radio" id="question2" name="Заказчик" type="radio" value="Организация" />
                           <label class="label_check-radio" for="question2">Организация</label>
                        </div>
                     </div>
                     <div class="privatePolocy_wrp">
                        <input class="with-font" id="privatePolocy2" type="checkbox" name="Условия использования данных" onchange="document.getElementById('submit_footer').disabled = !this.checked;" checked value="Пользователь принял условия использования данных"/>
                        <label class="privat-policy">Я&nbsp;принимаю условия использования данных <i class="fas fa-info-circle" data-toggle="modal" data-target="#privatPolicyall"></i></label> 
                     </div>
                     <input type="hidden" id="recaptchaV3_footer">
                     <button class="form_footer-btn" id="submit_footer" type="submit">Оставить заявку</button>
                  </div>
                  <div id="good_massege2"></div>
               </form>
            </div>
         </section>
         <!-- Modal -->
         <div class="modal fade" id="privatPolicyall" tabindex="-1" role="dialog" aria-labelledby="privatPolicyall" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
               <div class="modal-content">
                  <div class="modal-header">
                     <h5 class="modal-title" id="exampleModalLongTitle">Политика конфиденциальности</h5>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                     </button>
                  </div>
                  <div class="modal-body">
                     <h3>Сбор информации</h3>
                     <p>При оставлении заявки на&nbsp;ресурсе tk-aton.ru клиенты предоставляют следующие сведения:</p>
                     <ul>
                        <li>ФИО</li>
                        <li>Контактный E-mail (обязательно).</li>
                        <li>Контактный телефон (обязательно).</li>
                     </ul>
                     <p>Также администрация сайта получает данные об&nbsp;IP-адресе посетителей, а&nbsp;также о&nbsp;типе браузера, времени нахождения на&nbsp;сайте и&nbsp;прочие подобные сведения. Сбор ведётся с&nbsp;помощью сервисов статистики.</p>
                     <h3>Использование информации</h3>
                     <p>Вся полученная информация используется администрацией ресурса tk-aton.ru исключительно в&nbsp;целях связи с&nbsp;клиентом. Ресурс tk-aton.ru имеет право направлять клиенту информационные сообщения (новостную рассылку), если он&nbsp;подписался на&nbsp;них.</p>
                     <h3>Защита персональных данных</h3>
                     <p>Ресурс tk-aton.ru обязуется не&nbsp;разглашать сведения, полученные от&nbsp;клиентов. Она хранится в&nbsp;базе данных на&nbsp;локальном компьютере администрации. Доступ к&nbsp;компьютеру надёжно защищён паролем, который имеется только у&nbsp;администратора сайта.</p>
                     <h3>Предоставление данных третьим лицам</h3>
                     <p>Полученные сведения не&nbsp;могут быть переданы третьим лицам, за&nbsp;исключением следующих случаев:</p>
                     <ul>
                        <li>Для исполнения обязательств перед клиентом&nbsp;&mdash; только с&nbsp;его разрешения.</li>
                        <li>В&nbsp;соответствии с&nbsp;обоснованными и&nbsp;применимыми требованиями закона.</li>
                     </ul>
                     <h3>Контакты</h3>
                     <p>По&nbsp;всем вопросам вы&nbsp;можете обращаться к&nbsp;администрации сайта через раздел &laquo;Контакты&raquo;.</p>
                     <p>Настоящая редакция политики конфиденциальности опубликована 1&nbsp;апреля 2021&nbsp;года.</p>
                  </div>
                  <div class="modal-footer">
                     <button type="button" class="btn btn-secondary" data-dismiss="modal">Ознакомлен(а)</button>
                  </div>
               </div>
            </div>
         </div>
         <section id="contacts" class="contacts">
            <h2 class="contacts_h2">Наши контакты</h2>
            <div class="contacts_items__wrp">
               <div class="contacts_item">
                  <span class="contacts_item__span">г. Саратов</span>
                  <span class="contacts_item__span">ул. Гвардейская, 27Б</span>
               </div>
               <div class="contacts_item">
                  <span class="contacts_item__span">Тел.: +7 (8452) 39-81-22</span>
                  <span class="contacts_item__span">+7 (8452) 99-08-47</span>
               </div>
               <div class="contacts_item">
                  <span class="contacts_item__span">Е-mail: info@tk-aton.ru</span>
                  <span class="contacts_item__span">График работы: Пн-Пт 9:00&nbsp;&mdash; 18:00</span>
               </div>
            </div>
            <div class="contacts_items__wrp-mob">
               <div class="contacts_item-mob_left">
                  <span class="contacts_item__span">г. Саратов</span>
                  <span class="contacts_item__span">ул. Гвардейская, 27Б</span>
                  <span class="contacts_item__span">График работы:</span>
                  <span class="contacts_item__span">Пн-Пт 9:00&nbsp;&mdash; 18:00</span>
               </div>
               <div class="contacts_item-mob_right">
                  <span class="contacts_item__span">Е-mail: info@tk-aton.ru</span>
                  <span class="contacts_item__span">Тел.: +7 (8452) 39-81-22</span>
                  <span class="contacts_item__span contacts_item__span2">+7 (8452) 99-08-47</span>
               </div>
            </div>
            <div class="contacts_map">
               <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A0db1582a20da27bef9b3768ccfac6187985339238e3036e3f787ddcd071ca3c7&amp;width=100%25&amp;height=330&amp;lang=ru_RU&amp;scroll=true"></script>
            </div>
         </section>
         <footer>
            <div class="footer_logo">
               <a class="footer_logo_a" href="#header">
                  <picture class="footer_logo_img">
                     <source srcset="./img/logo.webp" type="image/webp">
                     <img src="./img/logo.png" height="93" alt="logo">
                  </picture>
                  <div class="footer_logo__txt">
                     <h2 class="logo_h2">Компания АТОН</h2>
                     <span class="logo_span">Продажа электрооборудования</span>
                  </div>
               </a>
            </div>
            <div class="footer_menu">
               <ul class="footer_menu__ul">
                  <li class="footer_menu__li"><a href="#product">Продукция</a></li>
                  <li class="footer_menu__li"><a href="#services">Услуги</a></li>
                  <li class="footer_menu__li"><a href="#company">О&nbsp;Компании</a></li>
                  <li class="footer_menu__li"><a href="#contacts">Контакты</a></li>
               </ul>
            </div>
            <div class="messenger_block">
               <div class="messenger">
                  <a title="Viber" href="viber://chat?number=79648781161">
                  <img class="messenger_img" src="./img/viber.svg" height="30" width="30" alt="Написать в Viber">
                  </a>
               </div>
               <div class="messenger">
                  <a title="Telegram" href="https://telegram.me/Vladimir_Prudnikov30" target="_blank" rel="nofollow">
                  <img class="messenger_img" src="./img/telegram.svg" height="30" width="30" alt="Написать в Telegram">
                  </a>
               </div>
               <div class="messenger">
                  <a title="Whatsapp" href="whatsapp://send?phone=79648781161">
                  <img class="messenger_img" src="./img/whatsapp.svg" height="30"  width="30" alt="Написать в Whatsapp">
                  </a>
               </div>
            </div>
         </footer>
      </div>
      <script src="/js/jquery-3.6.0.min.js"></script>
      <script src="/js/slick/slick.min.js"></script>
      <script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
      <script src="/js/main.js"></script>
      <script src="https://www.google.com/recaptcha/api.js?render=6Lft8KUaAAAAADw80Zl7X8-uw6bt45B-qktAfb3S" async defer></script>
      <script src="https://www.google.com/recaptcha/api.js" async defer></script>
      <script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer></script>
   </body>
</html>