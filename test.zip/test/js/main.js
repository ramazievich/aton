//слайдер
$(".slider").slick({

	centerMode: true,
	//autoplay: true,
	
	centerPadding: '120px',
	arrows: true,
	slidesToShow: 3,
	accessibility: true,
	responsive: [
	    {
			breakpoint: 1360,
			settings: {
				centerMode: true,
				centerPadding: '120px',
				arrows: true,
	            slidesToShow: 3,
	            accessibility: true,
			}
		},
		{
			breakpoint: 1200,
			settings: {
				centerMode: true,
				centerPadding: '60px',
	            slidesToShow: 3,
	            accessibility: true,
			}
		},
		{
			breakpoint: 850,
			settings: {
				arrows: false,
				centerMode: true,
				centerPadding: '10px',
				//dots: true,
				arrows: true,
				slidesToShow: 1,
                slidesToScroll: 1
			}
		},
		{
			breakpoint: 630,
			settings: {
				arrows: false,
				centerMode: true,
				centerPadding: '10px',
				dots: true,
				slidesToShow: 1,
                slidesToScroll: 1
			}
		}
	]
});





//Плавный переход по якорным ссылкам
$(document).ready(function () {
	$('a[href^="#"]').click(function () {
		elementClick = $(this).attr("href");

		destination = $(elementClick).offset().top;
		if ($.browser.safari) {
			$('body').animate({
				scrollTop: destination
			}, 1100);
		} else {
			$('html').animate({
				scrollTop: destination
			}, 1100);
		}
		return false;
	});
});



//Форма отправки

function validateEmail(email) {
    var mail = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
};


$(document).ready(function() {

	//E-mail Ajax Send
	$("form").submit(function() { //Change
		var th = $(this);
		$.ajax({
			type: "POST",
			url: "mail.php", //Change
			data: th.serialize()
		}).done(function addCode() {
			document.getElementById("good_massege_call").innerHTML += 
              "<h4 style='margin-top: 24px; font-size: 17px; border-radius: 5px; padding: 10px; color: #1b935b; background-color: #d1e7dd; font-weight: 300; border-color: #badbcc'>Спасибо за заявку!<br> В ближайшее время с Вами свяжется наш менеджер.</h4>";
			setTimeout(function() {
				// Done Functions
				th.trigger("reset");
			}, 1000);
			$(function(){
	$("#good_massege_call").delay(5000).slideUp(300);
});
document.getElementById("good_massege2").innerHTML += 
              "<h4 style='margin-top: 24px; font-size: 17px; border-radius: 5px; padding: 10px; color: #1b935b; background-color: #d1e7dd; font-weight: 300; border-color: #badbcc'>Спасибо за заявку!<br> В ближайшее время с Вами свяжется наш менеджер.</h4>";
			setTimeout(function() {
				// Done Functions
				th.trigger("reset");
			}, 1000);
			$(function(){
	$("#good_massege2").delay(5000).slideUp(300);
});
		});
		
		
		return false;
	});

});

//рекапча
function onloadCallback() {
    grecaptcha.ready(function () {
        grecaptcha.execute('6Lft8KUaAAAAADw80Zl7X8-uw6bt45B-qktAfb3S', { action: 'requestf_action' }).then(function (token) {
            var recaptchaResponse = document.getElementById('recaptchaV3');
            var recaptchaResponse2 = document.getElementById('recaptchaV3_footer');
            recaptchaResponse.value = token;
            recaptchaResponse2.value = token;
        });
    });
}

//
